export const GET_WIP = "GET_WIP";

export const loadWip = (data) => ({
  type: GET_WIP,
  payload: data,
});

const initialState = {
  data: null,
  loading: false,
  error: "",
};

const wipReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_WIP:
      return {
        ...state,
        data: action.payload,
      };

    default:
      return state;
  }
};

export default wipReducer;

export const GET_SHIFT_TARGET = "GET_SHIFT_TARGET";

export const loadshiftTarget = (data) => ({
  type: GET_SHIFT_TARGET,
  payload: data,
});

const initialState = {
  data: null,
  loading: false,
  error: "",
};

const shiftTargetReducer = (state = initialState, action) => {
  switch (action.type) {
    case GET_SHIFT_TARGET:
      return {
        ...state,
        data: action.payload,
      };

    default:
      return state;
  }
};

export default shiftTargetReducer;
